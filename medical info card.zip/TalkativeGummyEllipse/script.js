// Voice synthesis setup
const synth = window.speechSynthesis;
const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
recognition.continuous = false;
recognition.lang = 'en-US';

function speak(text) {
  const utterance = new SpeechSynthesisUtterance(text);
  const voices = synth.getVoices();
  const femaleVoice = voices.find(voice => 
    voice.name.includes('female') || 
    voice.name.includes('woman') ||
    voice.lang.startsWith('en')
  );
  
  if (femaleVoice) {
    utterance.voice = femaleVoice;
  }
  utterance.pitch = 1.2;
  utterance.rate = 0.9;
  utterance.volume = 1.0;
  synth.speak(utterance);
}

// LOGIN
const loginForm = document.getElementById('loginForm');
if (loginForm) {
  speak("Welcome to Medical Info Card. Please enter your login details.");
  loginForm.addEventListener('submit', function(e) {
    e.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const role = document.getElementById('role').value;
    const storedUser = JSON.parse(localStorage.getItem('user'));

    if (storedUser && username === storedUser.username && password === storedUser.password) {
      localStorage.setItem('loggedIn', 'true');
      localStorage.setItem('role', role);
      localStorage.setItem('currentUser', username);
      if (role === 'guardian') {
        window.location.href = 'guardian-details.html';
      } else {
        window.location.href = 'index1.html';
      }
    } else {
      document.getElementById('loginMessage').textContent = 'Invalid credentials or missing role';
    }
  });
}

// SIGN UP
const signupForm = document.getElementById('signupForm');
if (signupForm) {
  signupForm.addEventListener('submit', function(e) {
    e.preventDefault();
    const newUsername = document.getElementById('newUsername').value;
    const newPassword = document.getElementById('newPassword').value;

    const user = { username: newUsername, password: newPassword };
    localStorage.setItem('user', JSON.stringify(user));
    document.getElementById('signupMessage').textContent = 'Account created! Go to login.';
    setTimeout(() => {
      window.location.href = 'index.html';
    }, 1500);
  });
}

// LOGOUT
const logoutBtn = document.getElementById('logoutBtn');
if (logoutBtn) {
  logoutBtn.addEventListener('click', () => {
    localStorage.removeItem('loggedIn');
    localStorage.removeItem('role');
    window.location.href = 'index.html';
  });
}