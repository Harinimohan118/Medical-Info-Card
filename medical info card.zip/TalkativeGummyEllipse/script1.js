// Voice synthesis setup
const synth = window.speechSynthesis;

// Single speech recognition instance
const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
recognition.continuous = false;
recognition.lang = 'en-US';

// Debounced speak function
let speakTimeout;
function speak(text) {
  clearTimeout(speakTimeout);
  speakTimeout = setTimeout(() => {
    const utterance = new SpeechSynthesisUtterance(text);
    
    // Get available voices
    const voices = synth.getVoices();
    // Find a female voice
    const femaleVoice = voices.find(voice => 
      voice.name.includes('female') || 
      voice.name.includes('woman') ||
      voice.lang.startsWith('en') // Fallback to English voice
    );
    
    if (femaleVoice) {
      utterance.voice = femaleVoice;
    }
    
    // Configure voice parameters
    utterance.pitch = 1.2;    // Slightly higher pitch
    utterance.rate = 0.9;     // Slightly slower rate
    utterance.volume = 1.0;   // Full volume
    
    synth.speak(utterance);
  }, 100);
}

// Field configuration
const fields = [
  { id: 'name', guide: "Please enter your full name", required: true },
  { id: 'dob', guide: "Please enter your date of birth", required: true },
  { id: 'blood', guide: "Please enter your blood group", required: true },
  { id: 'allergies', guide: "Please list any allergies you have", required: false },
  { id: 'conditions', guide: "Please list any medical conditions", required: false },
  { id: 'contact', guide: "Please enter emergency contact information", required: true }
];

let currentFieldIndex = 0;

function showCurrentField() {
  // Hide all input groups
  document.querySelectorAll('.input-group').forEach(group => {
    group.style.display = 'none';
  });
  document.querySelector('button[type="submit"]').style.display = 'none';

  // Show current field
  const currentField = fields[currentFieldIndex];
  const currentGroup = document.querySelector(`#${currentField.id}`).parentElement;
  currentGroup.style.display = 'flex';
  
  // Show submit button if it's the last field
  if (currentFieldIndex === fields.length - 1) {
    document.querySelector('button[type="submit"]').style.display = 'block';
  }

  // Add next button if not the last field
  if (currentFieldIndex < fields.length - 1) {
    const nextButton = document.createElement('button');
    nextButton.textContent = 'Next';
    nextButton.type = 'button';
    nextButton.onclick = moveToNextField;
    currentGroup.appendChild(nextButton);
  }

  speak(currentField.guide);
}

function moveToNextField() {
  const currentField = fields[currentFieldIndex];
  const currentInput = document.getElementById(currentField.id);
  
  if (currentField.required && !currentInput.value) {
    speak("This field is required. Please fill it before moving to the next field.");
    return;
  }
  
  currentFieldIndex++;
  showCurrentField();
}

function startVoiceGuidance() {
  document.getElementById('guidanceChoice').style.display = 'none';
  document.querySelector('form').style.display = 'flex';
  
  speak("Welcome to the Medical Info Card form. I'll guide you through filling out each field one by one.");
  showCurrentField();
}

function skipVoiceGuidance() {
  document.getElementById('guidanceChoice').style.display = 'none';
  document.querySelector('form').style.display = 'flex';
}

// Voice recognition for initial choice
const choiceRecognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
choiceRecognition.continuous = false;
choiceRecognition.lang = 'en-US';

choiceRecognition.onstart = () => {
  console.log('Voice recognition started');
};

choiceRecognition.onerror = (event) => {
  console.error('Voice recognition error:', event.error);
  alert('Voice recognition failed. Please ensure you have given microphone permissions and are using a supported browser (Chrome recommended).');
};

choiceRecognition.onresult = (event) => {
  const transcript = event.results[0][0].transcript.toLowerCase();
  if (transcript.includes('1') || transcript.includes('one') || transcript.includes('yes')) {
    startVoiceGuidance();
  } else if (transcript.includes('2') || transcript.includes('two') || transcript.includes('no')) {
    skipVoiceGuidance();
  }
};

// Reset recognition on end
choiceRecognition.onend = () => {
  console.log('Voice recognition ended');
};

// Listen for both keyboard and voice input
document.addEventListener('keypress', (e) => {
  if (document.getElementById('guidanceChoice').style.display !== 'none') {
    if (e.key === '1') startVoiceGuidance();
    if (e.key === '2') skipVoiceGuidance();
  }
});
recognition.continuous = false;
recognition.lang = 'en-US';

let currentInput = null;
let currentButton = null;

// Handle microphone buttons
let isListening = false;

document.querySelectorAll('.mic-button').forEach(button => {
  button.addEventListener('click', () => {
    if (isListening) {
      recognition.stop();
      return;
    }
    
    const targetId = button.dataset.target;
    currentInput = document.getElementById(targetId);
    currentButton = button;
    
    try {
      button.classList.add('listening');
      isListening = true;
      recognition.start();
    } catch (error) {
      console.error('Recognition failed:', error);
      button.classList.remove('listening');
      isListening = false;
      alert('Please make sure your microphone is connected and you have given permission to use it.');
    }
  });
});

// Update recognition handlers
recognition.onend = () => {
  isListening = false;
  if (currentButton) {
    currentButton.classList.remove('listening');
  }
};

recognition.onresult = (event) => {
  const transcript = event.results[0][0].transcript;
  if (currentInput && currentInput.type === 'date') {
    // Try to parse date from speech
    const date = new Date(transcript);
    if (!isNaN(date)) {
      currentInput.value = date.toISOString().split('T')[0];
    }
  } else if (currentInput) {
    currentInput.value = transcript;
  }
};

recognition.onend = () => {
  if (currentButton) {
    currentButton.classList.remove('listening');
  }
};

recognition.onerror = (event) => {
  console.error('Speech recognition error:', event.error);
  if (currentButton) {
    currentButton.classList.remove('listening');
  }
};

document.querySelector("form").addEventListener("submit", function(e) {
  e.preventDefault();

  const name = document.getElementById("name").value;
  const dob = document.getElementById("dob").value;
  const blood = document.getElementById("blood").value;
  const allergies = document.getElementById("allergies").value;
  const conditions = document.getElementById("conditions").value;
  const contact = document.getElementById("contact").value;

  // Encode data as URL parameters
  const queryString = new URLSearchParams({
    name,
    dob,
    blood,
    allergies,
    conditions,
    contact
  }).toString();

  // Generate QR code with URL
  const fullUrl = `${window.location.origin}/view.html?${queryString}`;

  document.getElementById("qrSection").style.display = "block";
  document.getElementById("qrcode").innerHTML = ""; // Clear previous QR
  new QRCode(document.getElementById("qrcode"), fullUrl);
});
